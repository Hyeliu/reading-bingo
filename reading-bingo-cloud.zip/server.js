#!/usr/bin/env node
/* ===========================================================
   阅读大挑战 BINGO —— 局域网同步服务
   零依赖，只用 Node 内置模块。

   node server.js            默认 4321 端口
   PORT=8080 node server.js  换端口

   启动后同一 Wi-Fi 下的平板/手机打开终端里打印的地址即可
   （所有人共用一个「班级」数据，大屏实时刷新）
   =========================================================== */

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile, spawnSync } = require('child_process');

const ROOT = __dirname;
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT, 'data');
const STATE_FILE = path.join(DATA_DIR, 'state.json');
const PHOTO_DIR = path.join(DATA_DIR, 'photos');
const OCR_BIN = path.join(ROOT, 'tools', 'ocr');
const OCR_SRC = path.join(ROOT, 'tools', 'ocr.m');
const PORT = parseInt(process.env.PORT || '4321', 10);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2'
};

let state = { boards: {}, mission: null };

function loadState() {
  try {
    const raw = fs.readFileSync(STATE_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.boards) state = parsed;
    if (!state.mission) state.mission = null;
  } catch (e) {
    /* 第一次运行：没有数据文件 */
  }
}

let writeTimer = null;
function saveState() {
  clearTimeout(writeTimer);
  writeTimer = setTimeout(function () {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const tmp = STATE_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(state, null, 1));
      fs.renameSync(tmp, STATE_FILE);
    } catch (e) {
      console.error('保存失败：', e.message);
    }
  }, 150);
}

function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function sendFile(res, filePath) {
  fs.readFile(filePath, function (err, buf) {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('404'); return; }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-cache'
    });
    res.end(buf);
  });
}

function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  if (rel.indexOf('/photos/') === 0) {
    rel = path.join(PHOTO_DIR, rel.slice('/photos/'.length));
    return sendFile(res, rel);
  }
  const filePath = path.join(ROOT, path.normalize(rel).replace(/^(\.\.[/\\])+/, ''));
  if (!filePath.startsWith(ROOT)) { res.writeHead(403); res.end('forbidden'); return; }

  fs.readFile(filePath, function (err, buf) {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('404'); return; }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-cache'
    });
    res.end(buf);
  });
}

const server = http.createServer(function (req, res) {
  const parsed = new URL(req.url, 'http://localhost');
  const pathname = parsed.pathname;

  if (pathname === '/api/state' && req.method === 'GET') {
    json(res, 200, {
      boards: state.boards,
      mission: state.mission,
      caps: { ocr: ocrAvailable() }
    });
    return;
  }

  if (pathname === '/healthz') { json(res, 200, { ok: true }); return; }

  // 老师布置的任务（全班的棋盘都换成这套题目）
  if (pathname === '/api/mission' && req.method === 'POST') {
    readBody(req, 1024 * 1024, function (raw) {
      if (!raw) { json(res, 413, { error: 'too large' }); return; }
      let data;
      try { data = JSON.parse(raw); } catch (e) { json(res, 400, { error: 'bad json' }); return; }
      const m = data.mission;
      if (m === null) { state.mission = null; saveState(); json(res, 200, { ok: true }); return; }
      if (!m || !m.id || !Array.isArray(m.cells)) { json(res, 400, { error: 'bad mission' }); return; }
      if (!state.mission || (m.updatedAt || 0) >= (state.mission.updatedAt || 0)) {
        state.mission = m;
        saveState();
      }
      json(res, 200, { ok: true });
    });
    return;
  }

  if (pathname === '/api/state' && req.method === 'POST') {
    let body = '';
    req.on('data', function (c) {
      body += c;
      if (body.length > 2 * 1024 * 1024) req.destroy();
    });
    req.on('end', function () {
      try {
        const data = JSON.parse(body || '{}');
        const b = data.board;
        if (!b || !b.id || !Array.isArray(b.cells)) { json(res, 400, { error: 'bad board' }); return; }
        const cur = state.boards[b.id];
        if (!cur || (b.updatedAt || 0) >= (cur.updatedAt || 0)) {
          state.boards[b.id] = b;
          saveState();
        }
        json(res, 200, { ok: true, boards: Object.keys(state.boards).length });
      } catch (e) {
        json(res, 400, { error: 'bad json' });
      }
    });
    return;
  }

  // 拍照识字：图片 → mac 自带的视觉识别
  if (pathname === '/api/ocr' && req.method === 'POST') {
    readBody(req, 12 * 1024 * 1024, function (raw) {
      if (!raw) { json(res, 413, { error: 'too large' }); return; }
      let data;
      try { data = JSON.parse(raw); } catch (e) { json(res, 400, { error: 'bad json' }); return; }
      const buf = decodeImage(data.image);
      if (!buf) { json(res, 400, { error: 'bad image' }); return; }
      if (!ocrAvailable()) { json(res, 501, { error: 'ocr unavailable' }); return; }

      const tmpDir = path.join(DATA_DIR, 'tmp');
      fs.mkdirSync(tmpDir, { recursive: true });
      const tmp = path.join(tmpDir, 'ocr-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6) + '.jpg');
      fs.writeFileSync(tmp, buf);

      execFile(OCR_BIN, [tmp], { timeout: 20000, maxBuffer: 8 * 1024 * 1024 }, function (err, stdout) {
        try { fs.unlink(tmp, function () {}); } catch (e) {}
        if (err) { json(res, 500, { error: 'ocr failed' }); return; }
        try { json(res, 200, JSON.parse(stdout)); }
        catch (e) { json(res, 500, { error: 'bad ocr output' }); }
      });
    });
    return;
  }

  // 保存照片（大图放服务端，手机本地就不用存了）
  if (pathname === '/api/photo' && req.method === 'POST') {
    readBody(req, 12 * 1024 * 1024, function (raw) {
      if (!raw) { json(res, 413, { error: 'too large' }); return; }
      let data;
      try { data = JSON.parse(raw); } catch (e) { json(res, 400, { error: 'bad json' }); return; }
      const buf = decodeImage(data.image);
      if (!buf) { json(res, 400, { error: 'bad image' }); return; }
      fs.mkdirSync(PHOTO_DIR, { recursive: true });
      const name = 'p-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6) + '.jpg';
      fs.writeFileSync(path.join(PHOTO_DIR, name), buf);
      json(res, 200, { url: 'photos/' + name });
    });
    return;
  }

  // 老师用：清空全班数据
  if (pathname === '/api/reset' && req.method === 'POST') {
    state.boards = {};
    saveState();
    json(res, 200, { ok: true });
    return;
  }

  if (req.method === 'GET' || req.method === 'HEAD') { serveStatic(req, res, pathname); return; }

  res.writeHead(405); res.end('method not allowed');
});

function lanAddresses() {
  const out = [];
  const nets = os.networkInterfaces();
  Object.keys(nets).forEach(function (name) {
    nets[name].forEach(function (net) {
      if (net.family === 'IPv4' && !net.internal) out.push(net.address);
    });
  });
  return out;
}

function ocrAvailable() { return fs.existsSync(OCR_BIN); }

function ensureOcr() {
  if (process.platform !== 'darwin') return;   // 云端没有 mac 的文字识别
  if (fs.existsSync(OCR_BIN)) return;
  if (!fs.existsSync(OCR_SRC)) return;
  console.log('  首次运行：正在编译文字识别组件（约 3 秒）…');
  const r = spawnSync('clang', [
    '-fobjc-arc', '-O2',
    '-framework', 'Foundation', '-framework', 'Vision', '-framework', 'AppKit',
    '-o', OCR_BIN, OCR_SRC
  ], { encoding: 'utf8' });
  if (r.status === 0) console.log('  文字识别组件就绪');
  else console.log('  文字识别组件编译失败（不影响玩，只是不能拍照认书名）');
}

function readBody(req, limit, cb) {
  let body = '';
  let over = false;
  req.on('data', function (c) {
    body += c;
    if (body.length > limit && !over) { over = true; req.destroy(); }
  });
  req.on('end', function () { cb(over ? null : body); });
}

function decodeImage(dataUrl) {
  const m = /^data:image\/(?:jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=\s]+)$/.exec(dataUrl || '');
  if (!m) return null;
  return Buffer.from(m[1], 'base64');
}

loadState();
ensureOcr();
server.listen(PORT, '0.0.0.0', function () {
  const addrs = lanAddresses();
  console.log('');
  console.log('  阅读大挑战 BINGO 已启动');
  console.log('  ────────────────────────────');
  console.log('  这台电脑：  http://localhost:' + PORT);
  addrs.forEach(function (a) {
    console.log('  同一 Wi-Fi： http://' + a + ':' + PORT);
  });
  console.log('  已有 ' + Object.keys(state.boards).length + ' 位小朋友的数据');
  console.log('  大屏地址：  /#/wall');
  console.log('  按 Ctrl+C 停止');
  console.log('');
});
